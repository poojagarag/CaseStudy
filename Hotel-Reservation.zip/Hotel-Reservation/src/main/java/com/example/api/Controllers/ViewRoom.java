package com.example.api.Controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
public class ViewRoom {

	@Autowired
	private RestTemplate restTemplate;
	
	static final String INVENTORY_URL_MS="http://localhost:8081/";
	
	
	/*@GetMapping("/findAllDepartment")
	public String fetchDepartement() {
		Department department=restTemplate.exchange(OWNER_URL_MS+"/findAllDepartment", HttpMethod.GET,null,Department.class).getBody();
		System.out.print("Department"+department);
		return restTemplate.exchange(OWNER_URL_MS+"/findAllDepartment", HttpMethod.GET,null,String.class).getBody();
	}*/
	

	
	@GetMapping("/FindRoom")
	public String fetchAllDepartment() {
		return restTemplate.exchange(INVENTORY_URL_MS+"FindRoom",HttpMethod.GET,null,String.class).getBody();
	}


}
