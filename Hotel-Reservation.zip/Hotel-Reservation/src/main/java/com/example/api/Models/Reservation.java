package com.example.api.Models;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



@Document(collection = "Reservation")
public class Reservation {

	@Id
	private int reservationCode;
	
	private int memberCode;
	
	private int roomid;
	
	private int no_of_childrens;
	
	private int no_of_adults;
	
	private String checkInDate;
	
	private String checkOutDate;
	
	private boolean status;
	
	private int noOfNights;

	
	public int getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(int memberCode) {
		this.memberCode = memberCode;
	}

	public int getReservationCode() {
		return reservationCode;
	}

	public void setReservationCode(int reservationCode) {
		this.reservationCode = reservationCode;
	}

	public int getNo_of_childrens() {
		return no_of_childrens;
	}

	public void setNo_of_childrens(int no_of_childrens) {
		this.no_of_childrens = no_of_childrens;
	}

	public int getNo_of_adults() {
		return no_of_adults;
	}

	public void setNo_of_adults(int no_of_adults) {
		this.no_of_adults = no_of_adults;
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	public String getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getNoOfNights() {
		return noOfNights;
	}

	public void setNoOfNights(int noOfNights) {
		this.noOfNights = noOfNights;
	}

	public int getRoomid() {
		return roomid;
	}

	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}

	public Reservation(int reservationCode, int memberCode, int roomid, int no_of_childrens, int no_of_adults,
			String checkInDate, String checkOutDate, boolean status, int noOfNights) {
		super();
		this.reservationCode = reservationCode;
		this.memberCode = memberCode;
		this.roomid = roomid;
		this.no_of_childrens = no_of_childrens;
		this.no_of_adults = no_of_adults;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.status = status;
		this.noOfNights = noOfNights;
	}

	@Override
	public String toString() {
		return "Reservation [reservationCode=" + reservationCode + ", memberCode=" + memberCode + ", roomid=" + roomid
				+ ", no_of_childrens=" + no_of_childrens + ", no_of_adults=" + no_of_adults + ", checkInDate="
				+ checkInDate + ", checkOutDate=" + checkOutDate + ", status=" + status + ", noOfNights=" + noOfNights
				+ "]";
	}

	
	
	
	

}
