package com.example.api.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.api.Models.Guest;
import com.example.api.Repository.guestRepository;

@RestController
public class GuestController {
	@Autowired
	private guestRepository repository;
	
	@GetMapping("/Findguest")
	public ResponseEntity<?> getAllGuest(){
		
		List<Guest> guestDetailList = repository.findAll();
		if (guestDetailList.size() > 0) {
			
			return new ResponseEntity<List<Guest>>(guestDetailList , HttpStatus.OK);
		}
		else {
			
			return new ResponseEntity<>("No guest detail Available ", HttpStatus.NOT_FOUND);
		}	
	}
	//Get the single detail by using ID
	
		@GetMapping("/Findguestdetail/{memberCode}")
		
		public ResponseEntity<?> getSingleDetail(@PathVariable("memberCode") Integer id)
		{
			Optional<Guest> guestOptional=repository.findById(id);
			if(guestOptional.isPresent())
			{
				return new ResponseEntity<>(guestOptional.get(),HttpStatus.OK);
				
			}else
			{
				return new ResponseEntity<>("Guest not found with id" + id,HttpStatus.NOT_FOUND);
			}
		}
		//Post the details 

		@PostMapping("/Addguestdetail")
		public ResponseEntity<?> createGuest(@RequestBody Guest details)
		{
			try {
				repository.save(details);
				return new ResponseEntity<Guest>(details,HttpStatus.OK);
			} catch (Exception e) {
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
				}
		}
		
		//Updating the details
		
	    @PutMapping("/guestdetail/{memberCode}")
		
		public ResponseEntity<?> updateById(@PathVariable("memberCode") Integer id,@RequestBody Guest details)
		{
			Optional<Guest> guestOptional=repository.findById(id);
			if(guestOptional.isPresent())
			{
				Guest detailsToSave=guestOptional.get();
				detailsToSave.setPhnNo(details.getPhnNo() != null ? details.getPhnNo() : detailsToSave.getPhnNo());
				detailsToSave.setName(details.getName() != null ? details.getName() : detailsToSave.getName());
				detailsToSave.setEmail(details.getEmail()!=null ? details.getEmail():detailsToSave.getEmail());
				detailsToSave.setGender(details.getGender()!=null ? details.getGender():detailsToSave.getGender());
				repository.save(detailsToSave);
				return new ResponseEntity<>(detailsToSave,HttpStatus.OK);
				
			}else
			{
				return new ResponseEntity<>("Guest not found with id" + id,HttpStatus.NOT_FOUND);
			}
		}
	    
	    //Delete the details by using ID
	    
	    @DeleteMapping("/guestdetail/{memberCode}")
	    public ResponseEntity<?> deleteById(@PathVariable("memberCode") Integer id)
	    {
	    	try {
	    		repository.deleteById(id);
	    		return new ResponseEntity<>("Successfully deleted with id" + id,HttpStatus.OK);
	    		
	    	}catch(Exception e)
	    	{
	    		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	    	}
	    }	

}



