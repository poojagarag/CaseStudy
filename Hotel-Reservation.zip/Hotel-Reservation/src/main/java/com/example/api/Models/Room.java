package com.example.api.Models;

import org.springframework.data.annotation.Id;

import org.springframework.data.mongodb.core.mapping.Field;


public class Room {
	@Id
	private int roomid;
	
	@Field
	private int number;
	@Field
	private String type;
	@Field
	private int amount;
	@Field
	private String available;
	public Room(int roomid, int number, String type, int amount, String available) {
		super();
		this.roomid = roomid;
		this.number = number;
		this.type = type;
		this.amount = amount;
		this.available = available;
	}
	public int getRoomid() {
		return roomid;
	}
	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	
}
