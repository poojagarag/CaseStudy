package com.example.api.Controllers;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.api.Models.Reservation;
import com.example.api.Repository.ReservationRepository;

@RestController

public class ReservationController {
	@Autowired
	private ReservationRepository resrepo;
	
	@GetMapping("/reservation")
	public ResponseEntity<?> getAllReservation(){
		
		List<Reservation> reservationList = resrepo.findAll();
		if (reservationList.size() > 0) {
			
			return new ResponseEntity<List<Reservation>>(reservationList, HttpStatus.OK);
		}
		else {
			
			return new ResponseEntity<>("No guest detail Available ", HttpStatus.NOT_FOUND);
		}	
	}
	//Get the single detail by using ID
	
		@GetMapping("/reservationdetail/{reservationCode}")
		
		public ResponseEntity<?> getSingleDetail(@PathVariable("reservationCode") Integer id)
		{
			Optional<Reservation> reservationOptional=resrepo.findById(id);
			if(reservationOptional.isPresent())
			{
				return new ResponseEntity<>(reservationOptional.get(),HttpStatus.OK);
				
			}else
			{
				return new ResponseEntity<>("Guest not found with id" + id,HttpStatus.NOT_FOUND);
			}
		}
		//Post the details 

		@PostMapping("/reservationdetail")
		public ResponseEntity<?> createGuest(@RequestBody Reservation details)
		{
			try {
				resrepo.save(details);
				return new ResponseEntity<Reservation>(details,HttpStatus.OK);
			} catch (Exception e) {
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
				}
		}
		
		//Updating the details
		
	    @PutMapping("/reservationdetail/{reservationCode}")
		
		public ResponseEntity<?> updateById(@PathVariable("reservationCode") Integer id,@RequestBody Reservation details)
		{
			Optional<Reservation> reservationOptional=resrepo.findById(id);
			if(reservationOptional.isPresent())
			{
				Reservation detailsToSave=reservationOptional.get();
				detailsToSave.setMemberCode (details.getMemberCode() != 0 ? details.getMemberCode() : detailsToSave.getMemberCode());
				detailsToSave.setRoomid (details.getRoomid() != 0 ? details.getRoomid() : detailsToSave.getRoomid());
				
				detailsToSave.setNo_of_childrens(details.getNo_of_childrens() != 0 ? details.getNo_of_childrens() : detailsToSave.getNo_of_childrens());
				detailsToSave.setNo_of_adults(details.getNo_of_adults() != 0 ? details.getNo_of_adults() : detailsToSave.getNo_of_adults());
				detailsToSave.setCheckInDate(details.getCheckInDate()!=null ? details.getCheckInDate():detailsToSave.getCheckInDate());
				detailsToSave.setCheckOutDate(details.getCheckOutDate()!=null ? details.getCheckOutDate():detailsToSave.getCheckOutDate());
				detailsToSave.setStatus(details.isStatus()!=false ? details.isStatus():detailsToSave.isStatus());
				detailsToSave.setNoOfNights(details.getNoOfNights()!=0 ? details.getNoOfNights():detailsToSave.getNoOfNights());
				resrepo.save(detailsToSave);
				return new ResponseEntity<>(detailsToSave,HttpStatus.OK);
				
			}else
			{
				return new ResponseEntity<>("Reservation not found with id" + id,HttpStatus.NOT_FOUND);
			}
		}
	    
	    
	    
	    //Delete the details by using ID
	    
	    @DeleteMapping("/reservationdetail/{reservationCode}")
	    public ResponseEntity<?> deleteById(@PathVariable("reservationCode") Integer id)
	    {
	    	try {
	    		resrepo.deleteById(id);
	    		return new ResponseEntity<>("Successfully deleted with id" + id,HttpStatus.OK);
	    		
	    	}catch(Exception e)
	    	{
	    		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	    	}
	    }	
}
