package com.example.api.Models;

import org.springframework.data.annotation.Id;




public class Guest {
	@Id
	private int memberCode;
	
	private Long phnNo;
	
	private String name;
	
	private String email;
	
	private String gender;
	
	private String address;

	public int getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(int memberCode) {
		this.memberCode = memberCode;
	}

	public Long getPhnNo() {
		return phnNo;
	}

	public void setPhnNo(Long phnNo) {
		this.phnNo = phnNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	
	public Guest(int memberCode, Long phnNo, String name, String email, String gender, String address) {
		super();
		this.memberCode = memberCode;
		this.phnNo = phnNo;
		this.name = name;
		this.email = email;
		this.gender = gender;
		this.address = address;
	}

	@Override
	public String toString() {
		return "GuestDetails [memberCode=" + memberCode + ", phnNo=" + phnNo + ", name=" + name + ", Email=" + email
				+ ", gender=" + gender + ", Address=" + address + "]";
	}
	
	
	

}



