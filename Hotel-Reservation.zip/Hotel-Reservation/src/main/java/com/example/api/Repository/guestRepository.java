package com.example.api.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.api.Models.Guest;

public interface guestRepository extends MongoRepository<Guest,Integer>{

}
