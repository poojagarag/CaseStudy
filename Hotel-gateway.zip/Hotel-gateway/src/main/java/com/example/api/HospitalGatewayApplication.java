package com.example.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.web.bind.annotation.RestController;
@EnableEurekaClient
@SpringBootApplication
@EnableZuulProxy
@RestController
public class HospitalGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalGatewayApplication.class, args);
	}

}
