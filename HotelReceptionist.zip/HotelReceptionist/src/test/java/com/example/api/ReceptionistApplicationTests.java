package com.example.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceptionistApplicationTests {

	@Test
	void contextLoads() {
	}

}
