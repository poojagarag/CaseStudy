package com.example.api.Models;

import java.sql.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.web.bind.annotation.RestController;

@Document(collection="Reservation")
public class Reservation {
	
	@Id
	private int id;
	
	@Field
	private int numberOfChildrens;
	
	@Field
	private int numberOfAdults;
	
	@Field
	private Date date;
	
	@Field
	private String status;
	
	@Field
	private int numberOfNight;

	public Reservation(int id, int numberOfChildrens, int numberOfAdults, Date date, String status, int numberOfNight) {
		super();
		this.id = id;
		this.numberOfChildrens = numberOfChildrens;
		this.numberOfAdults = numberOfAdults;
		this.date = date;
		this.status = status;
		this.numberOfNight = numberOfNight;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumberOfChildrens() {
		return numberOfChildrens;
	}

	public void setNumberOfChildrens(int numberOfChildrens) {
		this.numberOfChildrens = numberOfChildrens;
	}

	public int getNumberOfAdults() {
		return numberOfAdults;
	}

	public void setNumberOfAdults(int numberOfAdults) {
		this.numberOfAdults = numberOfAdults;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getNumberOfNight() {
		return numberOfNight;
	}

	public void setNumberOfNight(int numberOfNight) {
		this.numberOfNight = numberOfNight;
	}

}
