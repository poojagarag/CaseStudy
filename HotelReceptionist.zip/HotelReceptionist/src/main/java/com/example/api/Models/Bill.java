package com.example.api.Models;

public class Bill {

}
