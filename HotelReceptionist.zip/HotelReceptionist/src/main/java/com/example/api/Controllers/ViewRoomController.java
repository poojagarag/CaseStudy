package com.example.api.Controllers;

public class ViewRoomController {

}
