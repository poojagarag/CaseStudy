package com.example.api.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.api.Models.Customer;



public interface CustomerRepository extends MongoRepository<Customer,Integer>{

}
