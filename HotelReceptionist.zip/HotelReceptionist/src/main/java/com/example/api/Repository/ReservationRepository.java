package com.example.api.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;


import com.example.api.Models.Reservation;

public interface ReservationRepository extends MongoRepository<Reservation,Integer>{

}
