package com.example.api.Repository;

import java.math.BigInteger;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.api.Models.Department;




public interface DepartmentRepository extends MongoRepository<Department,Integer>{

}
