package com.example.api.Controllers;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.api.Models.Department;

import com.example.api.Repository.DepartmentRepository;






@RestController
public class DepartmentController {
	@Autowired
	private DepartmentRepository repository;
	
	@GetMapping("/findAlldepartment")                         //Finding staff
	public List<Department> getdepartment(){
		return repository.findAll();
	}
	
		
	
	


	//Post the details 

		@PostMapping("/AddDepartment")
		public ResponseEntity<?> createDepartemnt(@RequestBody Department details)
		{
			
				repository.save(details);
				return new ResponseEntity<Department>(details,HttpStatus.OK);
			
		}
	
	
	

			
			//Updating the details
			
		 @PutMapping("/staffdetail/{staffCode}")
			
			public ResponseEntity<?> updateById(@PathVariable("Number") int number,@RequestBody Department details)
			{
				Optional<Department> departmentOptional=repository.findById(number);
				if(departmentOptional.isPresent())
				{
					Department detailsToSave=departmentOptional.get();
					detailsToSave.setNumber(details.getNumber() != null ? details.getNumber() : detailsToSave.getNumber());
					detailsToSave.setNumber(details.getNumber() != null ? details.getNumber() : detailsToSave.getNumber());
					detailsToSave.setName(details.getName() != null ? details.getName() : detailsToSave.getName());
					
					repository.save(detailsToSave);
					return new ResponseEntity<>(detailsToSave,HttpStatus.OK);
					
				}else
				{
					return new ResponseEntity<>("Staff not found with id" + number,HttpStatus.NOT_FOUND);
				}
			}
		    
		    //Delete the details by using ID
		    
	   @DeleteMapping("/departmentdetail/{number}")
		    public ResponseEntity<?> deleteById(@PathVariable("departmentnumber") int id)
		    {
		    	try {
		    		repository.deleteById(id);
		    		return new ResponseEntity<>("Successfully deleted with id" + id,HttpStatus.OK);
		    		
		    	}catch(Exception e)
		    	{
		    		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
		    	}
		    }	

}



