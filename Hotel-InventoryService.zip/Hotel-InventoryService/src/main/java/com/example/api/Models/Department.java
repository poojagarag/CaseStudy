package com.example.api.Models;

import org.springframework.data.annotation.Id;

import org.springframework.data.mongodb.core.mapping.Field;


public class Department {
	
	@Id
	private int id;
	
	@Field
	private int number;
	@Field
	private String name;
	public Department(int id, int number, String name) {
		super();
		this.id = id;
		this.number = number;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	

}
