package com.example.api.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;


import com.example.api.Models.Staff;

public interface StaffRepository extends MongoRepository<Staff, Integer> {

}
