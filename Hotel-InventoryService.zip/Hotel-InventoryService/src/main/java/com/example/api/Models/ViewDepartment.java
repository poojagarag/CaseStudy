package com.example.api.Models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ViewDepartment {
	@Autowired
	private RestTemplate restTemplate;
	
	static final String ADMINs_URL_MS="http://localhost:8083/";
	
	
	/*@GetMapping("/findAllDepartment")
	public String fetchDepartement() {
		Department department=restTemplate.exchange(OWNER_URL_MS+"/findAllDepartment", HttpMethod.GET,null,Department.class).getBody();
		System.out.print("Department"+department);
		return restTemplate.exchange(OWNER_URL_MS+"/findAllDepartment", HttpMethod.GET,null,String.class).getBody();
	}*/
	

	
	@GetMapping("/findAlldepartment")
	public String fetchAllDepartment() {
		return restTemplate.exchange(ADMINs_URL_MS+"findAlldepartment",HttpMethod.GET,null,String.class).getBody();
	}
}
