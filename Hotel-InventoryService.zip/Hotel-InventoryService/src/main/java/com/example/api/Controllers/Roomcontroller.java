package com.example.api.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.api.Models.Room;
import com.example.api.Repository.RoomRepository;

@RestController
public class Roomcontroller {
	@Autowired
	private RoomRepository repository;
	
	
	@GetMapping("/FindRoom")
	public ResponseEntity<?> getAllRoom(){
		List<Room> roomlist = repository.findAll();
		if (roomlist.size() > 0){
			return new ResponseEntity<List<Room>>(roomlist, HttpStatus.OK);
			
		}
		else
		{
			return new ResponseEntity<>("rooms not found", HttpStatus.NOT_FOUND );
			
		}
	
	}
	
	//Post the details 

		@PostMapping("/AddRoom")
		public ResponseEntity<?> createGuest(@RequestBody Room details)
		{
			try {
				repository.save(details);
				return new ResponseEntity<Room>(details,HttpStatus.OK);
			} catch (Exception e) {
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
				}
		}
	
	
	//Get the single detail by using ID
	
			@GetMapping("/AddRoom/{roomid}")
			
			public ResponseEntity<?> getSingleDetail(@PathVariable("roomid") Integer id)
			{
				Optional<Room> roomOptional=repository.findById(id);
				if(roomOptional.isPresent())
				{
					return new ResponseEntity<>(roomOptional.get(),HttpStatus.OK);
					
				}else
				{
					return new ResponseEntity<>("room not found with id" + id,HttpStatus.NOT_FOUND);
				}
			}
			
			//Updating the details
			
		    @PutMapping("/UpdateRoomd/{roomid}")
			
			public ResponseEntity<?> updateById(@PathVariable("roomid") Integer id,@RequestBody Room details)
			{
				Optional<Room> roomOptional=repository.findById(id);
				if(roomOptional.isPresent())
				{
					Room detailsToSave=roomOptional.get();
					
					detailsToSave.setAvailable(details.getAvailable() != null ? details.getAvailable() : detailsToSave.getAvailable());
					
					repository.save(detailsToSave);
					return new ResponseEntity<>(detailsToSave,HttpStatus.OK);
					
				}else
				{
					return new ResponseEntity<>("Room not found with id" + id,HttpStatus.NOT_FOUND);
				}
			}
		    
		    //Delete the details by using ID
		    
		    @DeleteMapping("/roomdetail/{roomid}")
		    public ResponseEntity<?> deleteById(@PathVariable("roomid") Integer id)
		    {
		    	try {
		    		repository.deleteById(id);
		    		return new ResponseEntity<>("Successfully deleted with id" + id,HttpStatus.OK);
		    		
		    	}catch(Exception e)
		    	{
		    		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
		    	}
		    }	

}



