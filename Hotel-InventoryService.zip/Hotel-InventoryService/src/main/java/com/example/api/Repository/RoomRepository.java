package com.example.api.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.api.Models.Room;

public interface RoomRepository extends MongoRepository<Room, Integer> {

}
