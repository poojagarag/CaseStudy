package com.example.api.Models;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Staff")
public class Staff {

	@Id
	private int staffCode;
	@Field
	private String employeeName;
	@Field
	private String emploeeAddress;
	@Field
	private Long salary;
	@Field
	private int age;
	@Field
	private String occupation;
	@Field
	private String email;
	@Field
	private String department;
	public Staff(int staffCode, String employeeName, String emploeeAddress, Long salary, int age, String occupation,
			String email, String department) {
		super();
		this.staffCode = staffCode;
		this.employeeName = employeeName;
		this.emploeeAddress = emploeeAddress;
		this.salary = salary;
		this.age = age;
		this.occupation = occupation;
		this.email = email;
		this.department = department;
	}
	public int getStaffCode() {
		return staffCode;
	}
	public void setStaffCode(int staffCode) {
		this.staffCode = staffCode;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmploeeAddress() {
		return emploeeAddress;
	}
	public void setEmploeeAddress(String emploeeAddress) {
		this.emploeeAddress = emploeeAddress;
	}
	public Long getSalary() {
		return salary;
	}
	public void setSalary(Long salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "Staff [staffCode=" + staffCode + ", employeeName=" + employeeName + ", emploeeAddress=" + emploeeAddress
				+ ", salary=" + salary + ", age=" + age + ", occupation=" + occupation + ", email=" + email
				+ ", department=" + department + "]";
	}

	
}


