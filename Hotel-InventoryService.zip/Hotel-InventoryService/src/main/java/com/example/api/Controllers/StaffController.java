package com.example.api.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.api.Models.Staff;
import com.example.api.Repository.StaffRepository;

@RestController
public class StaffController {
	@Autowired
	private StaffRepository repository;
	
	@GetMapping("/FindStaff")
	public ResponseEntity<?> getAllRoom(){
		List<Staff> stafflist = repository.findAll();
		if (stafflist.size() > 0){
			return new ResponseEntity<List<Staff>>(stafflist, HttpStatus.OK);
			
		}
		else
		{
			return new ResponseEntity<>("rooms not found", HttpStatus.NOT_FOUND );
			
		}
	
	}
	
	//Post the details 

		@PostMapping("/staffdetail")
		public ResponseEntity<?> createGuest(@RequestBody Staff details)
		{
			try {
				repository.save(details);
				return new ResponseEntity<Staff>(details,HttpStatus.OK);
			} catch (Exception e) {
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
				}
		}
	
	
	//Get the single detail by using ID
	
	/*		@GetMapping("/staffdetail/{staffCode}")
			
			public ResponseEntity<?> getSingleDetail(@PathVariable("staffCode") Integer staffCode)
			{
				Optional<Staff> staffOptional=repository.findById(staffCode);
				if(staffOptional.isPresent())
				{
					return new ResponseEntity<>(staffOptional.get(),HttpStatus.OK);
					
				}else
				{
					return new ResponseEntity<>("Staff not found with id" + staffCode,HttpStatus.NOT_FOUND);
				}
			}*/
			
			//Updating the details
			
		    @PutMapping("/staffdetail/{staffCode}")
			
			public ResponseEntity<?> updateById(@PathVariable("staffCode") Integer staffCode,@RequestBody Staff details)
			{
				Optional<Staff> staffOptional=repository.findById(staffCode);
				if(staffOptional.isPresent())
				{
					Staff detailsToSave=staffOptional.get();
					detailsToSave.setEmployeeName(details.getEmployeeName() != null ? details.getEmployeeName() : detailsToSave.getEmployeeName());
					detailsToSave.setEmploeeAddress(details.getEmploeeAddress() != null ? details.getEmploeeAddress() : detailsToSave.getEmploeeAddress());
					detailsToSave.setSalary(details.getSalary()!=null ? details.getSalary():detailsToSave.getSalary());
					detailsToSave.setAge(details.getAge()!= 0 ? details.getAge():detailsToSave.getAge());
					detailsToSave.setOccupation(details.getOccupation()!=null ? details.getOccupation():detailsToSave.getOccupation());
					detailsToSave.setEmail(details.getEmail()!=null ? details.getEmail():detailsToSave.getEmail());
					repository.save(detailsToSave);
					return new ResponseEntity<>(detailsToSave,HttpStatus.OK);
					
				}else
				{
					return new ResponseEntity<>("Staff not found with id" + staffCode,HttpStatus.NOT_FOUND);
				}
			}
		    
		    //Delete the details by using ID
		    
		    @DeleteMapping("/staffdetail/{staffCode}")
		    public ResponseEntity<?> deleteById(@PathVariable("staffCode") Integer id)
		    {
		    	try {
		    		repository.deleteById(id);
		    		return new ResponseEntity<>("Successfully deleted with id" + id,HttpStatus.OK);
		    		
		    	}catch(Exception e)
		    	{
		    		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
		    	}
		    }	

}


